import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";

import { marketAssets } from "@/constants/market-data";
import { ScreenContainer } from "@/components/screen-container";
import { AssetRow, BrandMark, palette, styles } from "@/components/market/market-components";

export default function WatchlistScreen() {
  const [filter, setFilter] = useState("هەموو");
  const filters = ["هەموو", "کریپتۆ", "سەهم", "کۆمۆدیتی"];
  const items = filter === "هەموو" ? marketAssets : marketAssets.filter((asset) => asset.category === filter);

  return (
    <ScreenContainer containerClassName="bg-[#0B1324]" safeAreaClassName="bg-[#0B1324]" className="bg-[#0B1324]">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 40 }}>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 25 }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}><BrandMark small /><View style={{ alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 18, fontWeight: "900" }}>چاودێری</Text><Text style={{ color: palette.muted, fontSize: 10, marginTop: 2 }}>لیستی داراییەکانت</Text></View></View>
          <Pressable style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: palette.surface, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: palette.border }}><Ionicons name="add" size={21} color={palette.mint} /></Pressable>
        </View>
        <View style={{ backgroundColor: palette.surfaceRaised, borderColor: palette.border, borderWidth: 1, borderRadius: 20, padding: 16, marginBottom: 22 }}>
          <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}><View style={{ alignItems: "flex-end" }}><Text style={{ color: palette.muted, fontSize: 11 }}>کۆی گۆڕانکاریی ئەمڕۆ</Text><Text style={{ color: palette.mint, fontSize: 25, fontWeight: "900", marginTop: 5 }}>+3.18%</Text></View><View style={{ width: 46, height: 46, borderRadius: 16, backgroundColor: palette.mintSoft, alignItems: "center", justifyContent: "center" }}><Ionicons name="bookmark" size={21} color={palette.mint} /></View></View>
          <Text style={{ color: palette.muted, fontSize: 11, textAlign: "right", marginTop: 12 }}>لە ٦ داراییی چاودێریکراو، ٤ دانەیان لە سەوزیدان.</Text>
        </View>
        <View style={{ flexDirection: "row-reverse", gap: 7, marginBottom: 18 }}>{filters.map((item) => <Pressable key={item} onPress={() => setFilter(item)} style={[styles.timeframe, filter === item && styles.timeframeActive]}><Text style={[styles.timeframeText, filter === item && styles.timeframeTextActive]}>{item}</Text></Pressable>)}</View>
        <View style={{ backgroundColor: palette.surface, borderRadius: 20, borderWidth: 1, borderColor: palette.border, paddingHorizontal: 14 }}>{items.map((asset) => <AssetRow key={asset.symbol} asset={asset} compact />)}</View>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8, marginTop: 18, padding: 13, backgroundColor: "#101B2E", borderRadius: 14 }}><Ionicons name="information-circle-outline" size={17} color={palette.muted} /><Text style={{ color: palette.muted, fontSize: 10, flex: 1, textAlign: "right" }}>ئەم نرخانە تەنها بۆ نموونەن و بۆ بڕیاردانی دارایی بەکارنەهێنە.</Text></View>
      </ScrollView>
    </ScreenContainer>
  );
}
