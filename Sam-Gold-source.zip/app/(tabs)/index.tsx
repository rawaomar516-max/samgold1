import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import { Linking, Platform, Pressable, ScrollView, Text, View } from "react-native";
import { WebView } from "react-native-webview";

import { dinarDollarTimeframes, type DinarDollarTimeframe } from "@/constants/market-data";
import { ScreenContainer } from "@/components/screen-container";
import { BrandMark, DinarDollarCandlestick, RsiIndicator, TimeframePills, TsiIndicator, palette } from "@/components/market/market-components";
import { apiCall } from "@/lib/_core/api";

const formatIqd = (value: number) => new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(Math.round(value));
type HatwanRate = { success?: boolean; buy?: number; sale?: number; mid?: number; updatedAt?: string | null };
const shiftCandlesToRate = (candles: typeof dinarDollarTimeframes["1D"], target: number) => {
  const shift = target - (candles[candles.length - 1]?.close ?? target);
  return candles.map((candle) => ({ ...candle, open: candle.open + shift, high: candle.high + shift, low: candle.low + shift, close: candle.close + shift }));
};

export default function DashboardScreen() {
  const [localTimeframe, setLocalTimeframe] = useState<DinarDollarTimeframe>("1D");
  const [showRsi, setShowRsi] = useState(false);
  const [showTsi, setShowTsi] = useState(false);
  const [hatwanCandles, setHatwanCandles] = useState<Partial<Record<DinarDollarTimeframe, typeof dinarDollarTimeframes["1D"]>>>({});
  const [hatwanRate, setHatwanRate] = useState<HatwanRate | null>(null);
  const [hatwanLoading, setHatwanLoading] = useState(true);
  const activeCandles = hatwanCandles[localTimeframe] ?? dinarDollarTimeframes[localTimeframe];
  const activeLatest = hatwanRate?.mid ?? activeCandles[activeCandles.length - 1]?.close ?? 148500;
  const activeChange = activeCandles.length > 1 ? ((activeCandles[activeCandles.length - 1].close - activeCandles[0].open) / activeCandles[0].open) * 100 : 0;
  const handleTimeframe = (value: string) => {
    setHatwanLoading(true);
    setLocalTimeframe(value as DinarDollarTimeframe);
  };

  useEffect(() => {
    const controller = new AbortController();
    const loadRate = () => {
      setHatwanLoading(true);
      return apiCall<HatwanRate>("/api/hatwan/usd-iqd", { signal: controller.signal, cache: "no-store" })
        .then((payload) => {
        if (!payload.success || typeof payload.mid !== "number") return;
        setHatwanRate(payload);
        setHatwanCandles((current) => ({ ...current, [localTimeframe]: shiftCandlesToRate(dinarDollarTimeframes[localTimeframe], payload.mid!) }));
        })
        .catch(() => {})
        .finally(() => setHatwanLoading(false));
    };
    void loadRate();
    const refreshTimer = setInterval(() => void loadRate(), 60_000);
    return () => {
      clearInterval(refreshTimer);
      controller.abort();
    };
  }, [localTimeframe]);

  return (
    <ScreenContainer containerClassName="bg-[#0B1324]" safeAreaClassName="bg-[#0B1324]" className="bg-[#0B1324]">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 18, paddingBottom: 32 }}>
        <View style={{ paddingTop: 14 }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginBottom: 30 }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
              <BrandMark />
              <View style={{ alignItems: "flex-end" }}>
                <Text style={{ color: palette.text, fontSize: 19, fontWeight: "900" }}>Sam Gold</Text>
                <Text style={{ color: palette.muted, fontSize: 10, marginTop: 1 }}>چارتی دۆلار و دینار</Text>
              </View>
            </View>
            <View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: palette.surface, borderWidth: 1, borderColor: palette.border, alignItems: "center", justifyContent: "center" }}>
              <Ionicons name="bar-chart-outline" size={18} color={palette.mint} />
            </View>
          </View>

          <View style={{ alignItems: "flex-end", marginBottom: 20 }}>
            <Text style={{ color: palette.mint, fontSize: 11, fontWeight: "800", marginBottom: 7 }}>بازاری ناوخۆ</Text>
            <Text style={{ color: palette.text, fontSize: 30, lineHeight: 36, fontWeight: "900", textAlign: "right" }}>دۆلار بەرامبەر دینار</Text>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 6, marginTop: 9 }}>
              <View style={{ width: 6, height: 6, borderRadius: 6, backgroundColor: palette.mint }} />
              <Text style={{ color: palette.muted, fontSize: 11 }}>{hatwanLoading ? "دەگات بە سەرچاوەی نرخ..." : "نرخی نوێکراوەی بازاری ناوخۆ"}</Text>
            </View>
          </View>

          <View style={{ backgroundColor: palette.surface, borderRadius: 24, borderWidth: 1, borderColor: palette.border, padding: 16 }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 18 }}>
              <View style={{ alignItems: "flex-end" }}>
                <Text style={{ color: palette.muted, fontSize: 11, fontWeight: "700" }}>نرخی ناوەندی بۆ ١٠٠$</Text>
                <View style={{ flexDirection: "row-reverse", alignItems: "baseline", gap: 8, marginTop: 4 }}>
                  <Text style={{ color: palette.text, fontSize: 25, fontWeight: "900" }}>{formatIqd(activeLatest)}</Text>
                  <Text style={{ color: activeChange >= 0 ? palette.mint : palette.red, fontSize: 11, fontWeight: "800" }}>{activeChange >= 0 ? "+" : ""}{activeChange.toFixed(2)}%</Text>
                </View>
                <Text style={{ color: palette.dim, fontSize: 10, marginTop: 5 }}>{hatwanLoading ? "کڕین و فرۆشتن نوێ دەکرێنەوە" : `کڕین ${formatIqd(hatwanRate?.buy ?? activeLatest)} • فرۆشتن ${formatIqd(hatwanRate?.sale ?? activeLatest)}`}</Text>
              </View>
              <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: palette.mintSoft, alignItems: "center", justifyContent: "center" }}><Text style={{ color: palette.mint, fontSize: 15, fontWeight: "900" }}>د.ع</Text></View>
            </View>

            <DinarDollarCandlestick candles={activeCandles} width={350} height={260} />
            <View style={{ alignItems: "flex-end", marginTop: 12 }}><TimeframePills options={["1H", "4H", "1D", "1W", "1M", "1Y"]} selected={localTimeframe} onSelect={handleTimeframe} /></View>

            <Pressable onPress={() => setShowRsi((value) => !value)} style={({ pressed }) => [{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginTop: 18, padding: 12, borderRadius: 13, borderWidth: 1, borderColor: showRsi ? palette.blue : palette.border, backgroundColor: showRsi ? "#6CA6FF18" : palette.surfaceRaised }, pressed && { opacity: 0.72 }]}>
              <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}><Ionicons name="pulse-outline" size={17} color={showRsi ? palette.blue : palette.muted} /><Text style={{ color: showRsi ? palette.blue : palette.text, fontSize: 12, fontWeight: "900" }}>زیادکردنی RSI (14)</Text></View>
              <View style={{ width: 34, height: 20, borderRadius: 20, backgroundColor: showRsi ? palette.blue : palette.border, padding: 3, alignItems: showRsi ? "flex-start" : "flex-end" }}><View style={{ width: 14, height: 14, borderRadius: 14, backgroundColor: palette.text }} /></View>
            </Pressable>
            {showRsi ? <RsiIndicator candles={activeCandles} width={350} height={122} period={14} /> : null}
            <Pressable onPress={() => setShowTsi((value) => !value)} style={({ pressed }) => [{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between", marginTop: 10, padding: 12, borderRadius: 13, borderWidth: 1, borderColor: showTsi ? palette.amber : palette.border, backgroundColor: showTsi ? "#F7C96A18" : palette.surfaceRaised }, pressed && { opacity: 0.72 }]}>
              <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}><Ionicons name="pulse-outline" size={17} color={showTsi ? palette.amber : palette.muted} /><Text style={{ color: showTsi ? palette.amber : palette.text, fontSize: 12, fontWeight: "900" }}>زیادکردنی TSI (25,13)</Text></View>
              <View style={{ width: 34, height: 20, borderRadius: 20, backgroundColor: showTsi ? palette.amber : palette.border, padding: 3, alignItems: showTsi ? "flex-start" : "flex-end" }}><View style={{ width: 14, height: 14, borderRadius: 14, backgroundColor: palette.text }} /></View>
            </Pressable>
            {showTsi ? <TsiIndicator candles={activeCandles} width={350} height={122} longPeriod={25} shortPeriod={13} /> : null}
          </View>

          <View style={{ backgroundColor: palette.surface, borderRadius: 24, borderWidth: 1, borderColor: palette.border, padding: 14, marginTop: 16, overflow: "hidden" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <View style={{ alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 17, fontWeight: "900" }}>زیو — XAG/USD</Text><Text style={{ color: palette.muted, fontSize: 10, marginTop: 3 }}>چارتی ڕاستەوخۆ لە TradingView</Text></View>
              <View style={{ width: 38, height: 38, borderRadius: 12, backgroundColor: "#F7C96A20", alignItems: "center", justifyContent: "center" }}><Text style={{ color: palette.amber, fontSize: 17, fontWeight: "900" }}>Ag</Text></View>
            </View>
            {Platform.OS === "web" ? <Pressable onPress={() => Linking.openURL("https://www.tradingview.com/chart/?symbol=OANDA%3AXAGUSD&interval=240")} style={({ pressed }) => [{ height: 160, borderRadius: 14, backgroundColor: "#0D1422", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: palette.border }, pressed && { opacity: 0.75 }]}><Ionicons name="open-outline" size={24} color={palette.amber} /><Text style={{ color: palette.text, fontSize: 12, fontWeight: "800", marginTop: 8 }}>کردنەوەی چارتی زیو لە TradingView</Text></Pressable> : <WebView source={{ uri: "https://www.tradingview.com/chart/?symbol=OANDA%3AXAGUSD&interval=240" }} style={{ height: 250, borderRadius: 14, backgroundColor: "#0D1422" }} originWhitelist={["*"]} javaScriptEnabled domStorageEnabled />}
          </View>

          <View style={{ flexDirection: "row-reverse", alignItems: "flex-start", gap: 9, backgroundColor: "#101B2E", borderRadius: 16, padding: 14, marginTop: 16 }}>
            <Ionicons name="information-circle-outline" size={18} color={palette.muted} />
            <Text style={{ flex: 1, color: palette.muted, fontSize: 11, lineHeight: 19, textAlign: "right" }}>چارتەکە بۆ ١٠٠ دۆلارە و هەر ٦٠ چرکە جارێک نرخی کڕین و فرۆشتن نوێ دەکاتەوە. RSI و TSI بۆ خوێندنەوەی ڕەوتن؛ چارتەی زیو لە TradingView ـەوە دەکرێتەوە.</Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
