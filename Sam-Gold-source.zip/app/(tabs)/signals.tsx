import { Ionicons } from "@expo/vector-icons";
import { useState } from "react";
import { Pressable, ScrollView, Text, TextInput, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { BrandMark, palette } from "@/components/market/market-components";

type Signal = { id: number; title: string; note: string; direction: "کڕین" | "فرۆشتن"; createdAt: string };

export default function SignalsScreen() {
  const [signals, setSignals] = useState<Signal[]>([]);
  const [title, setTitle] = useState("");
  const [note, setNote] = useState("");
  const [direction, setDirection] = useState<Signal["direction"]>("کڕین");

  const addSignal = () => {
    if (!title.trim()) return;
    setSignals((current) => [{ id: Date.now(), title: title.trim(), note: note.trim(), direction, createdAt: "ئێستا" }, ...current]);
    setTitle("");
    setNote("");
  };

  return (
    <ScreenContainer containerClassName="bg-[#0B1324]" safeAreaClassName="bg-[#0B1324]" className="bg-[#0B1324]">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 16, paddingBottom: 38 }}>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 28 }}>
          <BrandMark small />
          <View style={{ alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 19, fontWeight: "900" }}>Sam Gold</Text><Text style={{ color: palette.muted, fontSize: 10, marginTop: 2 }}>ئاماژەکانی مامەڵە</Text></View>
        </View>

        <View style={{ alignItems: "flex-end", marginBottom: 18 }}><Text style={{ color: palette.mint, fontSize: 11, fontWeight: "800", marginBottom: 7 }}>ئاماژە</Text><Text style={{ color: palette.text, fontSize: 29, lineHeight: 36, fontWeight: "900", textAlign: "right" }}>سیگناڵەکانت لێرە دابنێ</Text><Text style={{ color: palette.muted, fontSize: 12, lineHeight: 20, textAlign: "right", marginTop: 8 }}>ئەم بەشە بۆ تۆمارکردنی بیرۆکە و ئاماژەکانی خۆتە؛ هیچ مامەڵەیەک بە خۆکار جێبەجێ ناکرێت.</Text></View>

        <View style={{ backgroundColor: palette.surface, borderRadius: 22, borderWidth: 1, borderColor: palette.border, padding: 16, marginBottom: 22 }}>
          <TextInput value={title} onChangeText={setTitle} placeholder="ناوی ئاماژە، نموونە: XAG/USD" placeholderTextColor={palette.dim} style={{ color: palette.text, backgroundColor: palette.surfaceRaised, borderWidth: 1, borderColor: palette.border, borderRadius: 13, paddingHorizontal: 13, paddingVertical: 12, textAlign: "right", fontSize: 13 }} />
          <TextInput value={note} onChangeText={setNote} placeholder="تێبینی و هۆکاری سیگناڵ..." placeholderTextColor={palette.dim} multiline numberOfLines={3} style={{ color: palette.text, backgroundColor: palette.surfaceRaised, borderWidth: 1, borderColor: palette.border, borderRadius: 13, paddingHorizontal: 13, paddingVertical: 12, textAlign: "right", fontSize: 12, minHeight: 80, marginTop: 10, textAlignVertical: "top" }} />
          <View style={{ flexDirection: "row-reverse", gap: 8, marginTop: 10 }}>
            {(["کڕین", "فرۆشتن"] as const).map((value) => <Pressable key={value} onPress={() => setDirection(value)} style={{ flex: 1, alignItems: "center", paddingVertical: 11, borderRadius: 12, borderWidth: 1, borderColor: direction === value ? (value === "کڕین" ? palette.mint : palette.red) : palette.border, backgroundColor: direction === value ? (value === "کڕین" ? palette.mintSoft : "#F4868618") : palette.surfaceRaised }}><Text style={{ color: direction === value ? (value === "کڕین" ? palette.mint : palette.red) : palette.muted, fontSize: 12, fontWeight: "900" }}>{value}</Text></Pressable>)}
          </View>
          <Pressable onPress={addSignal} style={({ pressed }) => [{ flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: palette.mint, borderRadius: 13, paddingVertical: 13, marginTop: 12 }, pressed && { opacity: 0.75 }]}><Ionicons name="add" size={18} color={palette.background} /><Text style={{ color: palette.background, fontSize: 13, fontWeight: "900" }}>زیادکردنی ئاماژە</Text></Pressable>
        </View>

        <Text style={{ color: palette.text, fontSize: 18, fontWeight: "800", textAlign: "right", marginBottom: 12 }}>ئاماژە تۆمارکراوەکان</Text>
        {signals.length === 0 ? <View style={{ alignItems: "center", paddingVertical: 28, borderRadius: 18, borderWidth: 1, borderColor: palette.border, backgroundColor: palette.surface }}><Ionicons name="bookmark-outline" size={28} color={palette.dim} /><Text style={{ color: palette.muted, fontSize: 12, marginTop: 10 }}>هێشتا هیچ ئاماژەیەکت زیاد نەکردووە</Text></View> : signals.map((signal) => <View key={signal.id} style={{ flexDirection: "row-reverse", alignItems: "flex-start", gap: 11, backgroundColor: palette.surface, borderRadius: 17, borderWidth: 1, borderColor: palette.border, padding: 14, marginBottom: 10 }}><View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: signal.direction === "کڕین" ? palette.mintSoft : "#F4868618", alignItems: "center", justifyContent: "center" }}><Ionicons name={signal.direction === "کڕین" ? "arrow-up" : "arrow-down"} size={18} color={signal.direction === "کڕین" ? palette.mint : palette.red} /></View><View style={{ flex: 1, alignItems: "flex-end" }}><View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}><Text style={{ color: palette.text, fontSize: 13, fontWeight: "900" }}>{signal.title}</Text><Text style={{ color: signal.direction === "کڕین" ? palette.mint : palette.red, fontSize: 10, fontWeight: "800" }}>{signal.direction}</Text></View>{signal.note ? <Text style={{ color: palette.muted, fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 5 }}>{signal.note}</Text> : null}<Text style={{ color: palette.dim, fontSize: 10, marginTop: 5 }}>{signal.createdAt}</Text></View></View>)}
      </ScrollView>
    </ScreenContainer>
  );
}
