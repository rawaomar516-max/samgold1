import { Ionicons } from "@expo/vector-icons";
import type { ReactNode } from "react";
import { Pressable, ScrollView, Text, View } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { BrandMark, palette } from "@/components/market/market-components";

function SettingRow({ icon, title, detail, accent = palette.muted, trailing }: { icon: keyof typeof Ionicons.glyphMap; title: string; detail?: string; accent?: string; trailing?: ReactNode }) {
  return <Pressable style={({ pressed }) => [{ flexDirection: "row-reverse", alignItems: "center", gap: 12, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: palette.border }, pressed && { opacity: 0.7 }]}><View style={{ width: 34, height: 34, borderRadius: 11, backgroundColor: `${accent}18`, alignItems: "center", justifyContent: "center" }}><Ionicons name={icon} size={17} color={accent} /></View><View style={{ flex: 1, alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 13, fontWeight: "700", textAlign: "right" }}>{title}</Text>{detail ? <Text style={{ color: palette.muted, fontSize: 10, marginTop: 3, textAlign: "right" }}>{detail}</Text> : null}</View>{trailing ?? <Ionicons name="chevron-forward" size={15} color={palette.dim} />}</Pressable>;
}

export default function SettingsScreen() {
  return (
    <ScreenContainer containerClassName="bg-[#0B1324]" safeAreaClassName="bg-[#0B1324]" className="bg-[#0B1324]">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 40 }}>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 26 }}><BrandMark small /><View style={{ alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 18, fontWeight: "900" }}>ڕێکخستن</Text><Text style={{ color: palette.muted, fontSize: 10, marginTop: 2 }}>بازار بەپێی شێوازی تۆ</Text></View></View>
        <View style={{ backgroundColor: palette.surfaceRaised, borderRadius: 21, borderWidth: 1, borderColor: palette.border, padding: 17, marginBottom: 22 }}><View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12 }}><View style={{ width: 48, height: 48, borderRadius: 17, backgroundColor: palette.mint, alignItems: "center", justifyContent: "center" }}><Text style={{ color: palette.background, fontSize: 21, fontWeight: "900" }}>ب</Text></View><View style={{ flex: 1, alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 15, fontWeight: "900" }}>بەکارهێنەری بازار</Text><Text style={{ color: palette.muted, fontSize: 10, marginTop: 4 }}>پڕۆفایلی نموونەیی • Pro</Text></View><Ionicons name="ellipsis-horizontal" size={18} color={palette.muted} /></View></View>
        <Text style={{ color: palette.dim, fontSize: 11, fontWeight: "800", textAlign: "right", marginBottom: 8 }}>پەسەندکراوەکان</Text>
        <View style={{ backgroundColor: palette.surface, borderRadius: 18, borderWidth: 1, borderColor: palette.border, paddingHorizontal: 14, marginBottom: 20 }}>
          <SettingRow icon="notifications-outline" title="ئاگادارییەکان" detail="بۆ گۆڕانکارییە گرنگەکان" accent={palette.mint} trailing={<View style={{ width: 40, height: 24, backgroundColor: palette.mint, borderRadius: 20, padding: 3, alignItems: "flex-end" }}><View style={{ width: 18, height: 18, borderRadius: 18, backgroundColor: palette.background }} /></View>} />
          <SettingRow icon="moon-outline" title="شێوازی تاریک" detail="باشتر بۆ شیکاریی درێژخایەن" accent={palette.blue} trailing={<View style={{ width: 40, height: 24, backgroundColor: palette.mint, borderRadius: 20, padding: 3, alignItems: "flex-end" }}><View style={{ width: 18, height: 18, borderRadius: 18, backgroundColor: palette.background }} /></View>} />
          <SettingRow icon="language-outline" title="زمان" detail="کوردیی سۆرانی" accent={palette.amber} />
        </View>
        <Text style={{ color: palette.dim, fontSize: 11, fontWeight: "800", textAlign: "right", marginBottom: 8 }}>دەربارەی ئەپ</Text>
        <View style={{ backgroundColor: palette.surface, borderRadius: 18, borderWidth: 1, borderColor: palette.border, paddingHorizontal: 14 }}><SettingRow icon="shield-checkmark-outline" title="زانیارییەکانی داتا" detail="ئەم وەشانە mock ـە و live نییە" accent={palette.mint} /><SettingRow icon="help-circle-outline" title="یارمەتی و ڕێنمایی" accent={palette.muted} /><SettingRow icon="information-circle-outline" title="وەشان" detail="1.0.0 • Bazaar prototype" accent={palette.muted} trailing={<Text style={{ color: palette.dim, fontSize: 11 }}>v1.0</Text>} /></View>
      </ScrollView>
    </ScreenContainer>
  );
}
