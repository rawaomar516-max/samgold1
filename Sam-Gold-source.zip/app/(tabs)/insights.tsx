import { Ionicons } from "@expo/vector-icons";
import { ScrollView, Text, View } from "react-native";

import { insightItems } from "@/constants/market-data";
import { ScreenContainer } from "@/components/screen-container";
import { BrandMark, palette } from "@/components/market/market-components";

const toneColors = { mint: palette.mint, blue: palette.blue, amber: palette.amber };

export default function InsightsScreen() {
  return (
    <ScreenContainer containerClassName="bg-[#0B1324]" safeAreaClassName="bg-[#0B1324]" className="bg-[#0B1324]">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 40 }}>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 25 }}><BrandMark small /><View style={{ alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 18, fontWeight: "900" }}>تێڕوانینەکان</Text><Text style={{ color: palette.muted, fontSize: 10, marginTop: 2 }}>کورتەیەک بۆ بڕیاری ڕوون</Text></View></View>
        <View style={{ alignItems: "flex-end", marginBottom: 20 }}><Text style={{ color: palette.mint, fontSize: 11, fontWeight: "800", marginBottom: 6 }}>ئامادەیی بازار</Text><Text style={{ color: palette.text, fontSize: 29, fontWeight: "900", textAlign: "right" }}>بازار بە ئارامی دەجوڵێت.</Text><Text style={{ color: palette.muted, fontSize: 12, textAlign: "right", lineHeight: 20, marginTop: 8 }}>نیشاندەرەکان پێشبینییەکی هێمن بۆ ڕەوتی کورتخایەن پیشان دەدەن.</Text></View>
        <View style={{ backgroundColor: palette.surfaceRaised, borderRadius: 22, borderWidth: 1, borderColor: palette.border, padding: 17, marginBottom: 22 }}><View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}><View style={{ alignItems: "flex-end" }}><Text style={{ color: palette.muted, fontSize: 11 }}>هەستی گشتی</Text><Text style={{ color: palette.mint, fontSize: 27, fontWeight: "900", marginTop: 4 }}>ئارام</Text></View><View style={{ width: 52, height: 52, borderRadius: 17, backgroundColor: palette.mintSoft, alignItems: "center", justifyContent: "center" }}><Ionicons name="leaf-outline" size={24} color={palette.mint} /></View></View><View style={{ height: 7, backgroundColor: "#2A3A52", borderRadius: 7, marginTop: 18, overflow: "hidden" }}><View style={{ width: "74%", height: 7, backgroundColor: palette.mint, borderRadius: 7 }} /></View><Text style={{ color: palette.dim, fontSize: 10, textAlign: "right", marginTop: 8 }}>٢٤ لە ١٠٠ — ئاستی ترس و طمع</Text></View>
        <Text style={{ color: palette.text, fontSize: 18, fontWeight: "800", textAlign: "right", marginBottom: 12 }}>ئەوەی گرنگە بزانیت</Text>
        {insightItems.map((item) => <View key={item.title} style={{ flexDirection: "row-reverse", alignItems: "flex-start", gap: 12, backgroundColor: palette.surface, borderRadius: 18, borderWidth: 1, borderColor: palette.border, padding: 15, marginBottom: 10 }}><View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: `${toneColors[item.tone as keyof typeof toneColors]}20`, alignItems: "center", justifyContent: "center" }}><Ionicons name={item.icon as keyof typeof Ionicons.glyphMap} size={19} color={toneColors[item.tone as keyof typeof toneColors]} /></View><View style={{ flex: 1, alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 13, fontWeight: "800", textAlign: "right" }}>{item.title}</Text><Text style={{ color: palette.muted, fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 5 }}>{item.detail}</Text></View></View>)}
        <Text style={{ color: palette.dim, fontSize: 10, textAlign: "center", marginTop: 10 }}>نوێکردنەوەی داهاتوو: 15 خولەک</Text>
      </ScrollView>
    </ScreenContainer>
  );
}
