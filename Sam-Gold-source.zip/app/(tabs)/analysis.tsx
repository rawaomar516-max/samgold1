import { Ionicons } from "@expo/vector-icons";
import { ScrollView, Text, View } from "react-native";

import { insightItems } from "@/constants/market-data";
import { ScreenContainer } from "@/components/screen-container";
import { BrandMark, palette } from "@/components/market/market-components";

const toneColors = { mint: palette.mint, blue: palette.blue, amber: palette.amber };

export default function AnalysisScreen() {
  return (
    <ScreenContainer containerClassName="bg-[#0B1324]" safeAreaClassName="bg-[#0B1324]" className="bg-[#0B1324]">
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 18, paddingTop: 16, paddingBottom: 36 }}>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10, marginBottom: 28 }}>
          <BrandMark small />
          <View style={{ alignItems: "flex-end" }}>
            <Text style={{ color: palette.text, fontSize: 19, fontWeight: "900" }}>Sam Gold</Text>
            <Text style={{ color: palette.muted, fontSize: 10, marginTop: 2 }}>شیکاریی بازاری ناوخۆ</Text>
          </View>
        </View>

        <View style={{ alignItems: "flex-end", marginBottom: 18 }}>
          <Text style={{ color: palette.mint, fontSize: 11, fontWeight: "800", marginBottom: 7 }}>شیکاری</Text>
          <Text style={{ color: palette.text, fontSize: 29, lineHeight: 36, fontWeight: "900", textAlign: "right" }}>بازار بە هێمنی دەجوڵێت</Text>
          <Text style={{ color: palette.muted, fontSize: 12, lineHeight: 20, textAlign: "right", marginTop: 8 }}>کورتەیەکی ڕوون لە ڕەوتی دۆلار بەرامبەر دینار، بۆ ئەوەی بڕیارەکانت بە زانیاری بن.</Text>
        </View>

        <View style={{ backgroundColor: palette.surface, borderRadius: 22, borderWidth: 1, borderColor: palette.border, padding: 17, marginBottom: 18 }}>
          <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
            <View style={{ alignItems: "flex-end" }}>
              <Text style={{ color: palette.muted, fontSize: 11 }}>خوێندنەوەی گشتی</Text>
              <Text style={{ color: palette.mint, fontSize: 26, fontWeight: "900", marginTop: 4 }}>ئارام ـ بەرەو سەروو</Text>
            </View>
            <View style={{ width: 50, height: 50, borderRadius: 16, backgroundColor: palette.mintSoft, alignItems: "center", justifyContent: "center" }}><Ionicons name="analytics-outline" size={25} color={palette.mint} /></View>
          </View>
          <View style={{ height: 8, backgroundColor: "#2A3A52", borderRadius: 8, marginTop: 18, overflow: "hidden" }}><View style={{ width: "68%", height: 8, backgroundColor: palette.mint, borderRadius: 8 }} /></View>
          <Text style={{ color: palette.dim, fontSize: 10, textAlign: "right", marginTop: 8 }}>ڕەوتی کورتخایەن: بەرەو سەروو</Text>
        </View>

        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 18 }}>
          {[{ label: "ڕەوت", value: "بەرزبوونەوە", icon: "trending-up-outline" as const, color: palette.mint }, { label: "RSI", value: "لە ناوچەی ئارام", icon: "pulse-outline" as const, color: palette.blue }].map((item) => (
            <View key={item.label} style={{ flex: 1, backgroundColor: palette.surfaceRaised, borderRadius: 17, borderWidth: 1, borderColor: palette.border, padding: 14 }}>
              <Ionicons name={item.icon} size={18} color={item.color} />
              <Text style={{ color: palette.muted, fontSize: 10, textAlign: "right", marginTop: 10 }}>{item.label}</Text>
              <Text style={{ color: palette.text, fontSize: 12, fontWeight: "900", textAlign: "right", marginTop: 4 }}>{item.value}</Text>
            </View>
          ))}
        </View>

        <Text style={{ color: palette.text, fontSize: 18, fontWeight: "800", textAlign: "right", marginBottom: 12 }}>ئەوەی گرنگە بزانیت</Text>
        {insightItems.map((item) => {
          const color = toneColors[item.tone as keyof typeof toneColors];
          return <View key={item.title} style={{ flexDirection: "row-reverse", alignItems: "flex-start", gap: 12, backgroundColor: palette.surface, borderRadius: 18, borderWidth: 1, borderColor: palette.border, padding: 15, marginBottom: 10 }}><View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: `${color}20`, alignItems: "center", justifyContent: "center" }}><Ionicons name={item.icon as keyof typeof Ionicons.glyphMap} size={19} color={color} /></View><View style={{ flex: 1, alignItems: "flex-end" }}><Text style={{ color: palette.text, fontSize: 13, fontWeight: "800", textAlign: "right" }}>{item.title}</Text><Text style={{ color: palette.muted, fontSize: 11, lineHeight: 18, textAlign: "right", marginTop: 5 }}>{item.detail}</Text></View></View>;
        })}
      </ScrollView>
    </ScreenContainer>
  );
}
