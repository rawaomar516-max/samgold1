import { Tabs } from "expo-router";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { HapticTab } from "@/components/haptic-tab";
import { palette } from "@/components/market/market-components";

export default function TabLayout() {
  const insets = useSafeAreaInsets();
  const bottomPadding = Platform.OS === "web" ? 10 : Math.max(insets.bottom, 8);
  const tabBarHeight = 58 + bottomPadding;
  return (
    <Tabs screenOptions={{
      headerShown: false,
      tabBarActiveTintColor: palette.mint,
      tabBarInactiveTintColor: palette.dim,
      tabBarButton: HapticTab,
      tabBarLabelStyle: { fontSize: 10, fontWeight: "700", marginTop: -2 },
      tabBarStyle: { paddingTop: 8, paddingBottom: bottomPadding, height: tabBarHeight, backgroundColor: palette.background, borderTopColor: palette.border, borderTopWidth: 1 },
    }}>
      <Tabs.Screen name="index" options={{ title: "چارت", tabBarIcon: ({ color }) => <MaterialIcons size={22} name="show-chart" color={color} /> }} />
      <Tabs.Screen name="analysis" options={{ title: "شیکاری", tabBarIcon: ({ color }) => <MaterialIcons size={22} name="analytics" color={color} /> }} />
      <Tabs.Screen name="signals" options={{ title: "ئاماژە", tabBarIcon: ({ color }) => <MaterialIcons size={22} name="bookmark-border" color={color} /> }} />
      <Tabs.Screen name="watchlist" options={{ href: null }} />
      <Tabs.Screen name="insights" options={{ href: null }} />
      <Tabs.Screen name="settings" options={{ href: null }} />
    </Tabs>
  );
}
