import { Ionicons } from "@expo/vector-icons";
import { Fragment, useMemo } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import Svg, { Defs, LinearGradient as SvgGradient, Path, Rect, Stop, Text as SvgText } from "react-native-svg";

import type { Candle, MarketAsset } from "@/constants/market-data";

export const palette = {
  background: "#0B1324",
  surface: "#121D32",
  surfaceRaised: "#17243B",
  border: "#263650",
  text: "#F6F8FC",
  muted: "#93A1B7",
  dim: "#62708A",
  mint: "#9BE7C4",
  mintSoft: "#1D3B37",
  blue: "#6CA6FF",
  amber: "#F7C96A",
  red: "#F48686",
};

export function BrandMark({ small = false }: { small?: boolean }) {
  const size = small ? 32 : 42;
  return (
    <View style={[styles.brandMark, { width: size, height: size, borderRadius: small ? 10 : 13 }]}>
      <View style={styles.brandBarShort} />
      <View style={styles.brandBarTall} />
      <View style={styles.brandBarMid} />
    </View>
  );
}

export function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: string }) {
  return (
    <View style={styles.sectionTitleRow}>
      <View style={styles.sectionTitleCopy}>
        {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
        <Text style={styles.sectionTitle}>{title}</Text>
      </View>
      {action ? <Text style={styles.sectionAction}>{action}</Text> : null}
    </View>
  );
}

export function MetricCard({ label, value, note, positive, icon }: { label: string; value: string; note: string; positive: boolean; icon: keyof typeof Ionicons.glyphMap }) {
  return (
    <View style={styles.metricCard}>
      <View style={styles.metricIcon}><Ionicons name={icon} size={15} color={palette.mint} /></View>
      <Text style={styles.metricLabel}>{label}</Text>
      <Text style={styles.metricValue}>{value}</Text>
      <View style={styles.metricNoteRow}>
        <Ionicons name={positive ? "arrow-up" : "arrow-down"} size={11} color={positive ? palette.mint : palette.red} />
        <Text style={[styles.metricNote, { color: positive ? palette.mint : palette.red }]}>{note}</Text>
      </View>
    </View>
  );
}

export function MarketPulseCard() {
  return (
    <View style={styles.pulseCard}>
      <View style={styles.pulseHeader}>
        <View>
          <Text style={styles.pulseLabel}>هێزی گشتیی بازار</Text>
          <Text style={styles.pulseSub}>لەسەر بنەمای ١٠٠ نیشاندەر</Text>
        </View>
        <View style={styles.gainBadge}><Ionicons name="arrow-up" size={13} color={palette.mint} /><Text style={styles.gainText}>+2.4%</Text></View>
      </View>
      <View style={styles.pulseScoreRow}>
        <Text style={styles.pulseScore}>74.2</Text>
        <View style={styles.pulseStatus}><View style={styles.statusDot} /><Text style={styles.pulseStatusText}>بازار ئارامە</Text></View>
      </View>
      <View style={styles.scoreTrack}>
        <View style={[styles.scoreFill, { width: "74.2%" }]} />
        <View style={styles.scoreMarker} />
      </View>
      <View style={styles.scoreLegend}><Text style={styles.legendText}>لاواز</Text><Text style={styles.legendText}>ئارام</Text><Text style={styles.legendText}>بەهێز</Text></View>
    </View>
  );
}

function makePath(values: number[], width: number, height: number) {
  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;
  return values.map((value, index) => {
    const x = (index / (values.length - 1)) * width;
    const y = height - ((value - min) / range) * (height - 10) - 5;
    return `${index === 0 ? "M" : "L"}${x.toFixed(1)} ${y.toFixed(1)}`;
  }).join(" ");
}

export function Sparkline({ asset, large = false }: { asset: MarketAsset; large?: boolean }) {
  const width = large ? 330 : 94;
  const height = large ? 130 : 38;
  const path = useMemo(() => makePath(asset.sparkline, width, height), [asset.sparkline, height, width]);
  const gradientId = `spark-${asset.symbol.replace(/[^a-z0-9]/gi, "")}`;
  return (
    <Svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`}>
      <Defs><SvgGradient id={gradientId} x1="0" y1="0" x2="0" y2="1"><Stop offset="0" stopColor={asset.accent} stopOpacity="0.32" /><Stop offset="1" stopColor={asset.accent} stopOpacity="0" /></SvgGradient></Defs>
      {large ? [0, 1, 2, 3].map((row) => <Path key={row} d={`M0 ${row * 33 + 1} H${width}`} stroke="#2C3B54" strokeWidth="1" opacity="0.6" />) : null}
      <Path d={`${path} L${width} ${height} L0 ${height} Z`} fill={`url(#${gradientId})`} />
      <Path d={path} fill="none" stroke={asset.accent} strokeWidth={large ? 3 : 2.4} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function DinarDollarCandlestick({ candles, width = 330, height = 142 }: { candles: Candle[]; width?: number; height?: number }) {
  const chartTop = 8;
  const chartBottom = height - 20;
  const min = Math.min(...candles.map((candle) => candle.low));
  const max = Math.max(...candles.map((candle) => candle.high));
  const range = max - min || 1;
  const y = (value: number) => chartBottom - ((value - min) / range) * (chartBottom - chartTop);
  const axisWidth = 44;
  const plotWidth = width - axisWidth;
  const step = plotWidth / candles.length;
  const candleWidth = Math.min(height > 180 ? 22 : 14, step * 0.5);
  const gridStep = (chartBottom - chartTop) / 3;
  const format = (value: number) => `${(value / 1000).toFixed(1)}k`;
  const upColor = "#12B886";
  const downColor = "#F0445E";
  const closes = candles.map((candle) => candle.close);
  const maPeriod = Math.min(5, closes.length);
  const maPath = candles.map((_, index) => {
    const values = closes.slice(Math.max(0, index - maPeriod + 1), index + 1);
    const average = values.reduce((sum, value) => sum + value, 0) / values.length;
    const x = step * index + step / 2;
    return `${index === 0 ? "M" : "L"}${x.toFixed(1)} ${y(average).toFixed(1)}`;
  }).join(" ");
  const lastCandle = candles[candles.length - 1];
  const lastColor = lastCandle && lastCandle.close >= lastCandle.open ? upColor : downColor;
  const lastPriceY = lastCandle ? y(lastCandle.close) : chartTop;

  return (
    <Svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`}>
      {[0, 1, 2, 3].map((row) => {
        const level = max - (range * row) / 3;
        const gridY = chartTop + row * gridStep;
        return <Fragment key={row}><Path d={`M0 ${gridY} H${plotWidth}`} stroke="#2C3B54" strokeWidth="1" opacity="0.75" /><SvgText x={plotWidth + 4} y={gridY + 4} fill={palette.dim} fontSize="8">{format(level)}</SvgText></Fragment>;
      })}
      {maPath ? <Path d={maPath} fill="none" stroke="#F28C28" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" opacity="0.95" /> : null}
      {candles.map((candle, index) => {
        const x = step * index + step / 2;
        const openY = y(candle.open);
        const closeY = y(candle.close);
        const highY = y(candle.high);
        const lowY = y(candle.low);
        const rising = candle.close >= candle.open;
        const color = rising ? upColor : downColor;
        const bodyY = Math.min(openY, closeY);
        const bodyHeight = Math.max(Math.abs(closeY - openY), 4);
        return <Fragment key={`${candle.label}-${index}`}>{candle.wick !== false ? <Path d={`M${x} ${highY} V${lowY}`} stroke={color} strokeWidth="1.5" opacity="0.95" /> : null}<Rect x={x - candleWidth / 2} y={bodyY} width={candleWidth} height={bodyHeight} rx="1" fill={color} stroke={color} strokeWidth="1" /></Fragment>;
      })}
      <Path d={`M0 ${chartBottom} H${plotWidth}`} stroke="#42516A" strokeWidth="1" />
      {lastCandle ? <Fragment><Path d={`M0 ${lastPriceY} H${plotWidth}`} stroke={lastColor} strokeWidth="1" strokeDasharray="3 3" opacity="0.6" /><Rect x={plotWidth + 1} y={Math.max(chartTop, Math.min(chartBottom - 16, lastPriceY - 8))} width={axisWidth - 2} height="16" rx="2" fill={lastColor} /><SvgText x={plotWidth + 4} y={Math.max(chartTop + 11, Math.min(chartBottom - 4, lastPriceY + 4))} fill="#FFFFFF" fontSize="8" fontWeight="700">{format(lastCandle.close)}</SvgText></Fragment> : null}
      <SvgText x="3" y={height - 4} fill={palette.dim} fontSize="8">{candles[0]?.label}</SvgText>
      <SvgText x={plotWidth / 2 - 13} y={height - 4} fill={palette.dim} fontSize="8">{candles[Math.floor(candles.length / 2)]?.label}</SvgText>
      <SvgText x={plotWidth - 28} y={height - 4} fill={palette.dim} fontSize="8">{candles[candles.length - 1]?.label}</SvgText>
    </Svg>
  );
}

export function RsiIndicator({ candles, width = 330, height = 112, period = 14 }: { candles: Candle[]; width?: number; height?: number; period?: number }) {
  const closes = candles.map((candle) => candle.close);
  const effectivePeriod = Math.max(2, Math.min(period, Math.max(2, closes.length - 1)));
  const values = closes.map((_, index) => {
    if (index === 0) return 50;
    const start = Math.max(1, index - effectivePeriod + 1);
    let gains = 0;
    let losses = 0;
    for (let cursor = start; cursor <= index; cursor += 1) {
      const delta = closes[cursor] - closes[cursor - 1];
      if (delta >= 0) gains += delta;
      else losses -= delta;
    }
    if (losses === 0) return gains === 0 ? 50 : 100;
    return 100 - 100 / (1 + gains / losses);
  });
  const chartTop = 12;
  const chartBottom = height - 18;
  const axisWidth = 28;
  const plotWidth = width - axisWidth;
  const step = plotWidth / Math.max(values.length, 1);
  const y = (value: number) => chartBottom - (value / 100) * (chartBottom - chartTop);
  const path = values.map((value, index) => `${index === 0 ? "M" : "L"}${(step * index + step / 2).toFixed(1)} ${y(value).toFixed(1)}`).join(" ");
  const latest = values[values.length - 1] ?? 50;

  return (
    <View style={{ marginTop: 14 }}>
      <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 5 }}>
        <Text style={{ color: palette.muted, fontSize: 10, fontWeight: "800" }}>RSI ({period})</Text>
        <Text style={{ color: latest >= 70 ? palette.red : latest <= 30 ? palette.mint : palette.blue, fontSize: 11, fontWeight: "900" }}>{latest.toFixed(1)}</Text>
      </View>
      <Svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`}>
        {[70, 50, 30].map((level) => <Fragment key={level}><Path d={`M0 ${y(level)} H${plotWidth}`} stroke={level === 50 ? "#42516A" : "#2C3B54"} strokeWidth="1" strokeDasharray={level === 50 ? undefined : "3 3"} opacity="0.8" /><SvgText x={plotWidth + 4} y={y(level) + 3} fill={palette.dim} fontSize="8">{level}</SvgText></Fragment>)}
        {path ? <Path d={path} fill="none" stroke={palette.blue} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /> : null}
      </Svg>
    </View>
  );
}

export function TsiIndicator({ candles, width = 330, height = 112, longPeriod = 25, shortPeriod = 13 }: { candles: Candle[]; width?: number; height?: number; longPeriod?: number; shortPeriod?: number }) {
  const closes = candles.map((candle) => candle.close);
  const momentum = closes.map((close, index) => index === 0 ? 0 : close - closes[index - 1]);
  const ema = (values: number[], period: number) => {
    const alpha = 2 / (period + 1);
    return values.reduce<number[]>((result, value, index) => {
      result.push(index === 0 ? value : alpha * value + (1 - alpha) * result[index - 1]);
      return result;
    }, []);
  };
  const smoothMomentum = ema(ema(momentum, longPeriod), shortPeriod);
  const smoothAbsoluteMomentum = ema(ema(momentum.map(Math.abs), longPeriod), shortPeriod);
  const values = smoothMomentum.map((value, index) => smoothAbsoluteMomentum[index] ? (100 * value) / smoothAbsoluteMomentum[index] : 0);
  const chartTop = 12;
  const chartBottom = height - 18;
  const axisWidth = 30;
  const plotWidth = width - axisWidth;
  const step = plotWidth / Math.max(values.length, 1);
  const y = (value: number) => chartBottom - ((value + 100) / 200) * (chartBottom - chartTop);
  const path = values.map((value, index) => `${index === 0 ? "M" : "L"}${(step * index + step / 2).toFixed(1)} ${y(value).toFixed(1)}`).join(" ");
  const latest = values[values.length - 1] ?? 0;

  return (
    <View style={{ marginTop: 14 }}>
      <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 5 }}>
        <Text style={{ color: palette.muted, fontSize: 10, fontWeight: "800" }}>TSI ({longPeriod},{shortPeriod})</Text>
        <Text style={{ color: latest >= 25 ? palette.mint : latest <= -25 ? palette.red : palette.blue, fontSize: 11, fontWeight: "900" }}>{latest.toFixed(1)}</Text>
      </View>
      <Svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`}>
        {[-25, 0, 25].map((level) => <Fragment key={level}><Path d={`M0 ${y(level)} H${plotWidth}`} stroke={level === 0 ? "#42516A" : "#2C3B54"} strokeWidth="1" strokeDasharray={level === 0 ? undefined : "3 3"} opacity="0.8" /><SvgText x={plotWidth + 4} y={y(level) + 3} fill={palette.dim} fontSize="8">{level}</SvgText></Fragment>)}
        {path ? <Path d={path} fill="none" stroke={palette.amber} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /> : null}
      </Svg>
    </View>
  );
}

export function AssetRow({ asset, onPress, compact = false }: { asset: MarketAsset; onPress?: () => void; compact?: boolean }) {
  const positive = asset.changeValue >= 0;
  const content = (
    <View style={[styles.assetRow, compact && styles.assetRowCompact]}>
      <View style={[styles.assetIcon, { backgroundColor: `${asset.accent}22` }]}><Text style={[styles.assetIconText, { color: asset.accent }]}>{asset.symbol.slice(0, 1)}</Text></View>
      <View style={styles.assetNameBlock}>
        <Text style={styles.assetSymbol}>{asset.symbol}</Text>
        <Text style={styles.assetName}>{asset.name}</Text>
      </View>
      {!compact ? <View style={styles.assetSpark}><Sparkline asset={asset} /></View> : null}
      <View style={styles.assetNumbers}>
        <Text style={styles.assetPrice}>{asset.price}</Text>
        <Text style={[styles.assetChange, { color: positive ? palette.mint : palette.red }]}>{asset.change}</Text>
      </View>
      <Ionicons name="chevron-forward" size={15} color={palette.dim} />
    </View>
  );
  return onPress ? <Pressable onPress={onPress} style={({ pressed }) => [pressed && styles.pressed]}>{content}</Pressable> : content;
}

export function TimeframePills({ selected, onSelect, options = ["1D", "1W", "1M", "1Y"] }: { selected: string; onSelect: (value: string) => void; options?: string[] }) {
  return (
    <View style={styles.timeframeRow}>
      {options.map((timeframe) => {
        const active = timeframe === selected;
        return <Pressable key={timeframe} onPress={() => onSelect(timeframe)} style={[styles.timeframe, active && styles.timeframeActive]}><Text style={[styles.timeframeText, active && styles.timeframeTextActive]}>{timeframe}</Text></Pressable>;
      })}
    </View>
  );
}

export const styles = StyleSheet.create({
  brandMark: { backgroundColor: palette.mint, alignItems: "center", justifyContent: "center", flexDirection: "row", gap: 3 },
  brandBarShort: { width: 3, height: 9, borderRadius: 3, backgroundColor: palette.background },
  brandBarTall: { width: 3, height: 17, borderRadius: 3, backgroundColor: palette.background },
  brandBarMid: { width: 3, height: 13, borderRadius: 3, backgroundColor: palette.background },
  sectionTitleRow: { flexDirection: "row-reverse", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 12 },
  sectionTitleCopy: { alignItems: "flex-end" },
  eyebrow: { color: palette.mint, fontSize: 11, fontWeight: "700", letterSpacing: 1.1, marginBottom: 4 },
  sectionTitle: { color: palette.text, fontSize: 21, fontWeight: "800", textAlign: "right" },
  sectionAction: { color: palette.mint, fontSize: 12, fontWeight: "700", paddingBottom: 2 },
  metricCard: { flex: 1, minWidth: 0, backgroundColor: palette.surface, borderColor: palette.border, borderWidth: 1, borderRadius: 16, padding: 12, alignItems: "flex-end" },
  metricIcon: { width: 26, height: 26, borderRadius: 9, backgroundColor: palette.mintSoft, alignItems: "center", justifyContent: "center", marginBottom: 10, alignSelf: "flex-end" },
  metricLabel: { color: palette.muted, fontSize: 10, textAlign: "right", marginBottom: 5 },
  metricValue: { color: palette.text, fontSize: 16, fontWeight: "800", letterSpacing: 0.2 },
  metricNoteRow: { flexDirection: "row", alignItems: "center", gap: 2, marginTop: 5 },
  metricNote: { fontSize: 10, fontWeight: "700" },
  pulseCard: { overflow: "hidden", borderRadius: 24, borderWidth: 1, borderColor: "#2D4567", backgroundColor: "#162640", padding: 18, marginBottom: 20 },
  pulseHeader: { flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" },
  pulseLabel: { color: palette.text, fontSize: 14, fontWeight: "800", textAlign: "right" },
  pulseSub: { color: palette.muted, fontSize: 10, marginTop: 4, textAlign: "right" },
  gainBadge: { flexDirection: "row", alignItems: "center", backgroundColor: palette.mintSoft, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 6, gap: 2 },
  gainText: { color: palette.mint, fontSize: 11, fontWeight: "800" },
  pulseScoreRow: { flexDirection: "row-reverse", alignItems: "baseline", justifyContent: "space-between", marginTop: 18 },
  pulseScore: { color: palette.text, fontSize: 42, fontWeight: "900", letterSpacing: -1 },
  pulseStatus: { flexDirection: "row-reverse", alignItems: "center", gap: 6 },
  statusDot: { width: 7, height: 7, borderRadius: 7, backgroundColor: palette.mint },
  pulseStatusText: { color: palette.mint, fontSize: 12, fontWeight: "700" },
  scoreTrack: { height: 8, borderRadius: 8, backgroundColor: "#2B3B54", marginTop: 14, overflow: "hidden", position: "relative" },
  scoreFill: { height: "100%", backgroundColor: palette.mint, borderRadius: 8 },
  scoreMarker: { position: "absolute", right: "24%", top: -2, width: 3, height: 12, backgroundColor: palette.text, borderRadius: 3 },
  scoreLegend: { flexDirection: "row", justifyContent: "space-between", marginTop: 8 },
  legendText: { color: palette.dim, fontSize: 9 },
  assetRow: { flexDirection: "row-reverse", alignItems: "center", minHeight: 69, borderBottomWidth: 1, borderBottomColor: palette.border, gap: 10 },
  assetRowCompact: { minHeight: 63 },
  assetIcon: { width: 36, height: 36, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  assetIconText: { fontSize: 16, fontWeight: "900" },
  assetNameBlock: { flex: 1, alignItems: "flex-end", minWidth: 0 },
  assetSymbol: { color: palette.text, fontWeight: "800", fontSize: 13 },
  assetName: { color: palette.muted, fontSize: 10, marginTop: 2, textAlign: "right" },
  assetSpark: { width: 66, height: 34, opacity: 0.9 },
  assetNumbers: { alignItems: "flex-end", minWidth: 72 },
  assetPrice: { color: palette.text, fontSize: 12, fontWeight: "800" },
  assetChange: { fontSize: 10, fontWeight: "800", marginTop: 3 },
  timeframeRow: { flexDirection: "row-reverse", gap: 6 },
  timeframe: { borderRadius: 9, borderWidth: 1, borderColor: palette.border, paddingHorizontal: 10, paddingVertical: 6, minWidth: 38, alignItems: "center" },
  timeframeActive: { backgroundColor: palette.mint, borderColor: palette.mint },
  timeframeText: { color: palette.muted, fontSize: 10, fontWeight: "800" },
  timeframeTextActive: { color: palette.background },
  pressed: { opacity: 0.72 },
});
