import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { createCorsMiddleware } from "./cors";
import { clearLegacySessionCookie } from "./cookies";

async function startServer() {
  const app = express();
  const server = createServer(app);

  app.use(createCorsMiddleware());
  app.use(clearLegacySessionCookie());

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerStorageProxy(app);
  registerOAuthRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.get("/api/rudaw/currency-history", async (req, res) => {
    const range = typeof req.query.range === "string" && ["day", "week", "month", "year"].includes(req.query.range) ? req.query.range : "day";
    const days = typeof req.query.days === "string" ? req.query.days : range === "year" ? "365" : range === "month" ? "30" : range === "week" ? "7" : "1";
    const url = new URL("https://api.rudaw.net/api/currency-history");
    url.searchParams.set("from", "USD");
    url.searchParams.set("to", "IQD");
    url.searchParams.set("range", range);
    url.searchParams.set("days", days);

    try {
      const response = await fetch(url, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(8000) });
      if (!response.ok) return res.status(502).json({ success: false, error: "Rudaw rate source unavailable" });
      const payload = await response.json() as { success?: boolean; from?: string; to?: string; data?: unknown[] };
      if (!payload.success || !Array.isArray(payload.data)) return res.status(502).json({ success: false, error: "Invalid Rudaw rate response" });
      res.setHeader("Cache-Control", "public, max-age=60, s-maxage=60");
      return res.json({ success: true, source: "Rudaw", from: payload.from ?? "USD", to: payload.to ?? "IQD", data: payload.data });
    } catch {
      return res.status(502).json({ success: false, error: "Could not reach Rudaw rate source" });
    }
  });

  app.get("/api/hatwan/usd-iqd", async (_req, res) => {
    try {
      const response = await fetch("https://hatwanexchange.com/", { headers: { Accept: "text/html" }, signal: AbortSignal.timeout(8000) });
      if (!response.ok) return res.status(502).json({ success: false, error: "Hatwan rate source unavailable" });
      const html = await response.text();
      const match = html.match(/<div id="app"[^>]*data-page="([^"]+)"/i);
      if (!match) return res.status(502).json({ success: false, error: "Hatwan rate payload not found" });
      const pageJson = match[1].replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">");
      const page = JSON.parse(pageJson) as { props?: { currencies?: Array<{ currency_code?: string; buy?: number; sale?: number; updated_at?: string }> } };
      const usd = page.props?.currencies?.find((currency) => currency.currency_code === "USD");
      if (!usd || typeof usd.buy !== "number" || typeof usd.sale !== "number") return res.status(502).json({ success: false, error: "USD rate missing from Hatwan" });
      res.setHeader("Cache-Control", "public, max-age=60, s-maxage=60");
      return res.json({ success: true, source: "Hatwan Exchange", currency: "USD/IQD", unit: "IQD_PER_100_USD", buy: usd.buy, sale: usd.sale, mid: (usd.buy + usd.sale) / 2, updatedAt: usd.updated_at ?? null });
    } catch {
      return res.status(502).json({ success: false, error: "Could not read Hatwan rate source" });
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  const port = parseInt(process.env.PORT || "3000");
  server.listen(port, () => {
    console.log("[api] server listening");
  });
}

startServer().catch(() => {
  console.error("[api] server failed to start");
});
