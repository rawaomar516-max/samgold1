/** @type {const} */
const themeColors = {
  primary: { light: '#9BE7C4', dark: '#9BE7C4' },
  background: { light: '#0B1324', dark: '#0B1324' },
  surface: { light: '#121D32', dark: '#121D32' },
  foreground: { light: '#F6F8FC', dark: '#F6F8FC' },
  muted: { light: '#93A1B7', dark: '#93A1B7' },
  border: { light: '#263650', dark: '#263650' },
  success: { light: '#9BE7C4', dark: '#9BE7C4' },
  warning: { light: '#F7C96A', dark: '#F7C96A' },
  error: { light: '#F48686', dark: '#F48686' },
};

module.exports = { themeColors };
