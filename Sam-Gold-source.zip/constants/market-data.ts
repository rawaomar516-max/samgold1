export type MarketAsset = {
  symbol: string;
  name: string;
  price: string;
  change: string;
  changeValue: number;
  accent: string;
  category: string;
  sparkline: number[];
};

export type Candle = {
  label: string;
  open: number;
  high: number;
  low: number;
  close: number;
  wick?: boolean;
};

// داتای نموونەییە بۆ ڕووکاری بازاری ناوخۆ؛ نرخە live ـەکان نیین.
export const dinarDollarCandles: Candle[] = [
  { label: "10:00", open: 147900, high: 148200, low: 147700, close: 148100, wick: true },
  { label: "11:00", open: 148100, high: 148100, low: 148000, close: 148000, wick: false },
  { label: "12:00", open: 148000, high: 148600, low: 147900, close: 148450, wick: true },
  { label: "13:00", open: 148450, high: 148580, low: 148450, close: 148580, wick: false },
  { label: "14:00", open: 148580, high: 148800, low: 148300, close: 148420, wick: true },
  { label: "15:00", open: 148420, high: 148760, low: 148420, close: 148760, wick: false },
  { label: "16:00", open: 148760, high: 149050, low: 148600, close: 148900, wick: true },
  { label: "17:00", open: 148900, high: 148900, low: 148500, close: 148500, wick: false },
];

export type DinarDollarTimeframe = "1H" | "4H" | "1D" | "1W" | "1M" | "1Y";

const makeCandleSeries = (labels: string[], closes: number[], spread: number): Candle[] => labels.map((label, index) => {
  const open = index === 0 ? closes[0] - spread : closes[index - 1];
  const close = closes[index];
  const hasWick = index % 3 !== 1;
  return { label, open, close, high: hasWick ? Math.max(open, close) + spread : Math.max(open, close), low: hasWick ? Math.min(open, close) - spread : Math.min(open, close), wick: hasWick };
});

export const dinarDollarTimeframes: Record<DinarDollarTimeframe, Candle[]> = {
  "1H": dinarDollarCandles,
  "4H": makeCandleSeries(["٠٤", "٠٨", "١٢", "١٦", "٢٠", "٢٤", "٢٨", "٣٢"], [148120, 148360, 148280, 148640, 148520, 148760, 148690, 148920], 115),
  "1D": makeCandleSeries(["س", "٢", "٣", "٤", "٥", "٦", "٧", "٨"], [148050, 148240, 148120, 148460, 148380, 148720, 148640, 148500], 90),
  "1W": makeCandleSeries(["ش", "ی", "د", "س", "چ", "پ", "ه"], [147900, 148220, 148080, 148460, 148730, 148560, 148840], 130),
  "1M": makeCandleSeries(["هەف ١", "هەف ٢", "هەف ٣", "هەف ٤", "هەف ٥", "هەف ٦"], [146800, 147450, 147100, 148050, 148420, 148840], 220),
  "1Y": makeCandleSeries(["بەهار", "هاوین", "پاییز", "زستان", "ئازار", "خەرمانان"], [139500, 142800, 141900, 145600, 147200, 148840], 520),
};

export const marketAssets: MarketAsset[] = [
  {
    symbol: "BTC",
    name: "Bitcoin",
    price: "$67,842",
    change: "+4.82%",
    changeValue: 4.82,
    accent: "#F59E0B",
    category: "کریپتۆ",
    sparkline: [28, 31, 29, 36, 34, 42, 45, 43, 49, 55, 52, 61],
  },
  {
    symbol: "ETH",
    name: "Ethereum",
    price: "$3,482",
    change: "+2.16%",
    changeValue: 2.16,
    accent: "#818CF8",
    category: "کریپتۆ",
    sparkline: [42, 38, 41, 40, 44, 47, 45, 52, 49, 56, 58, 60],
  },
  {
    symbol: "NVDA",
    name: "NVIDIA Corp.",
    price: "$138.85",
    change: "+5.41%",
    changeValue: 5.41,
    accent: "#84CC16",
    category: "سەهم",
    sparkline: [22, 24, 26, 25, 31, 29, 38, 35, 42, 46, 51, 58],
  },
  {
    symbol: "AAPL",
    name: "Apple Inc.",
    price: "$231.41",
    change: "-0.82%",
    changeValue: -0.82,
    accent: "#CBD5E1",
    category: "سەهم",
    sparkline: [54, 56, 52, 55, 51, 48, 50, 47, 45, 48, 44, 43],
  },
  {
    symbol: "GOLD",
    name: "Gold / USD",
    price: "$2,672",
    change: "+0.64%",
    changeValue: 0.64,
    accent: "#FCD34D",
    category: "کۆمۆدیتی",
    sparkline: [32, 34, 33, 36, 35, 37, 38, 37, 40, 39, 42, 43],
  },
  {
    symbol: "EUR/USD",
    name: "یۆرۆ بەرامبەر دۆلار",
    price: "1.0892",
    change: "-0.18%",
    changeValue: -0.18,
    accent: "#38BDF8",
    category: "فۆرێکس",
    sparkline: [50, 49, 52, 48, 50, 47, 48, 46, 45, 46, 44, 45],
  },
];

export const marketStats = [
  { label: "قەبارەی مامەڵە", value: "$1.28T", note: "+8.6%", positive: true },
  { label: "ئاستی ترس", value: "24 / 100", note: "ئارام", positive: true },
  { label: "سەهمی گەشە", value: "68%", note: "بەرز", positive: true },
];

export const timeframes = ["1D", "1W", "1M", "1Y"] as const;
export type Timeframe = (typeof timeframes)[number];

export const insightItems = [
  { icon: "trending-up", title: "ڕەوتی دۆلار بەرەو سەرووە", detail: "جوڵەی نرخی دۆلار بەرامبەر دینار لە تایم‌فرێمی ڕۆژانەدا بەرەو سەرووە.", tone: "mint" },
  { icon: "pulse", title: "بازار لە دۆخی ئارامدا", detail: "جیاوازی نرخی کڕین و فرۆشتن بە شێوەیەکی هێمن چاودێری دەکرێت.", tone: "blue" },
  { icon: "alert-circle-outline", title: "چاودێری نرخی ناوخۆ", detail: "پێش هەر بڕیارێک نرخی نوێکراوەی ١٠٠ دۆلار و RSI ببینە.", tone: "amber" },
];
